﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class cadTrimestre : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["op"] = "I";
            txtAno.Text = DateTime.Today.Year.ToString();
        }

    }
    protected void btnGravar_Click(object sender, EventArgs e)
    {
        if (Session["op"] == "I")
            gravarItem();
        else
            if (Session["op"] == "A")
            alterarItem();

        Session["trimestre"] = cboTrimestre.SelectedValue;
        Session["formaContrat"] = cboFormacontrat.SelectedValue;
        Session["ano"] = txtAno.Text;

        GridView1.DataBind();

    }
    private void alterarItem()
    {
        dbClass db = new dbClass();
        string sql = "update sipXtrimestre set ";
        sql += " qt_evento = " + txtQtEventos.Text;
        sql += ", qt_benef_fora_per_carencia = " + txtQtBenefCarencia.Text;
        sql += ", tt_despesa_liq = " + txtTtDespLiq.Text.Replace(".", "").Replace(",", "."); 
        sql += " where cd_empresa = " + cboEmpresa.SelectedValue;
        sql += " and ano = " + txtAno.Text;
        sql += " and trimestre = " + cboTrimestre.SelectedValue;
        sql += " and uf = '" + txtUF.Text + "'";
        sql +=" and formaContratacao = '" + cboFormacontrat.SelectedValue + "'";
        sql += " and cd_sip = '" + cboItemAssit.SelectedValue + "'";
        db.execmd(sql, false);

    }
    private void gravarItem()
    {
        dbClass db = new dbClass();
        string sql = "insert into sipXtrimestre (cd_empresa, ano, trimestre, uf, formaContratacao, cd_sip, qt_evento,qt_benef_fora_per_carencia, tt_despesa_liq) values (";
        sql += cboEmpresa.SelectedValue + ",";
        sql += txtAno.Text + ",";
        sql += cboTrimestre.SelectedValue + ",'";
        sql += txtUF.Text + "','";
        sql += cboFormacontrat.SelectedValue + "','";
        sql += cboItemAssit.SelectedValue + "',";
        sql += txtQtEventos.Text + ",";
        sql += txtQtBenefCarencia.Text + ",";
        sql += txtTtDespLiq.Text.Replace(".", "").Replace(",", ".") + ")";
        db.execmd(sql, false);
        limpaTela();

    }

    private void limpaTela()
    {
        Session["op"] = "I";
        if (Session["trimestre"] != null)
            cboTrimestre.SelectedValue = Session["trimestre"].ToString();

        if (Session["formaContrat"] != null)
            cboFormacontrat.SelectedValue = Session["formaContrat"].ToString();
        if (Session["ano"] != null)
            txtAno.Text = Session["ano"].ToString();

        txtQtBenefCarencia.Text = "";
        txtQtEventos.Text = "";
        txtTtDespLiq.Text = "";        

    }


    protected void cboItemAssit_SelectedIndexChanged(object sender, EventArgs e)
    {
        dbClass db = new dbClass();
        SqlDataReader dr = db.DataReader("select * from sipXtrimestre where cd_empresa = " + cboEmpresa.SelectedValue + " and ano = " + txtAno.Text + " and trimestre = " + cboTrimestre.SelectedValue + " and uf = '" + txtUF.Text + "' and formaContratacao = '" + cboFormacontrat.SelectedValue + "' and cd_sip = '" + cboItemAssit.SelectedValue + "'");
        if (dr.Read())
        {
            txtQtBenefCarencia.Text = dr["qt_benef_fora_per_carencia"].ToString();
            txtQtEventos.Text = dr["qt_evento"].ToString();
            txtTtDespLiq.Text = dr["tt_despesa_liq"].ToString();
            Session["op"] = "A";
        }
        else
        {
            txtQtBenefCarencia.Text = "";
            txtQtEventos.Text = "";
            txtTtDespLiq.Text = "";
            Session["op"] = "I";

        }
        txtQtEventos.Focus();
        dr.Close();
        db.closeConn();

    }
    protected void cboEmpresa_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridView1.DataBind();
    }
}